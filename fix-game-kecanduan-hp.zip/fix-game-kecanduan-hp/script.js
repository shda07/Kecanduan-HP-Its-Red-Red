const questions = [
  {
    icon: "📚",
    question: "Kamu sedang belajar, lalu notifikasi media sosial muncul. Apa yang kamu lakukan?",
    choices: ["Cek notifikasi sebentar, lalu lanjut belajar.", "Abaikan dulu dan selesaikan sesi belajar."],
    answer: 1,
    good: "Good choice! Kamu menjaga fokus dan menyelesaikan kegiatan belajar terlebih dahulu. Kamu bisa mengecek notifikasi saat waktu istirahat.",
    bad: "Mengecek notifikasi dapat membuat fokus terpecah dan tugas tertunda. Coba aktifkan mode fokus saat belajar."
  },
  {
    icon: "🌙",
    question: "Sudah waktunya tidur, tetapi kamu masih ingin bermain HP. Apa pilihanmu?",
    choices: ["Terus bermain HP sampai mengantuk.", "Simpan HP dan mulai bersiap untuk tidur."],
    answer: 1,
    good: "Tepat! Mengurangi penggunaan HP sebelum tidur membantu menjaga waktu istirahat.",
    bad: "Terus bermain HP bisa membuat waktu istirahat terganggu. Besok kamu mungkin merasa kurang segar."
  },
  {
    icon: "🍽️",
    question: "Kamu sedang makan bersama keluarga. Apa yang sebaiknya dilakukan?",
    choices: ["Letakkan HP dan ikut mengobrol.", "Tetap melihat video sambil makan."],
    answer: 0,
    good: "Good choice! Kamu memberi perhatian kepada keluarga dan menikmati waktu bersama.",
    bad: "Kamu bisa melewatkan obrolan dan momen bersama orang-orang di sekitarmu."
  },
  {
    icon: "⏳",
    question: "Kamu sadar sudah bermain HP jauh lebih lama dari rencana. Apa langkah terbaik?",
    choices: ["Lanjut saja, tanggung sudah terlanjur.", "Berhenti sejenak dan atur batas waktu."],
    answer: 1,
    good: "Bagus! Menyadari kebiasaan adalah langkah awal untuk mengatur penggunaan HP.",
    bad: "Mengabaikan waktu bisa membuat kebiasaan sulit dikendalikan. Coba mulai dengan jeda singkat."
  },
  {
    icon: "⚽",
    question: "Kamu punya waktu luang di akhir pekan. Apa pilihan yang lebih seimbang?",
    choices: ["Menghabiskan seluruh waktu dengan HP.", "Membagi waktu untuk aktivitas di luar dan di dalam HP."],
    answer: 1,
    good: "Keren! Kamu tetap bisa menikmati teknologi sekaligus melakukan kegiatan lain.",
    bad: "Terlalu lama menggunakan HP bisa membuat kesempatan bergerak, mencoba hobi, atau bertemu teman terlewat."
  }
];

const $ = (id) => document.getElementById(id);
let current = 0;
let score = 0;
let answered = false;

function renderQuestion() {
  const q = questions[current];
  answered = false;
  $("gameContent").hidden = false;
  $("gameResult").hidden = true;
  $("scenarioIcon").textContent = q.icon;
  $("questionText").textContent = q.question;
  $("choiceA").textContent = q.choices[0];
  $("choiceB").textContent = q.choices[1];
  $("progressLabel").textContent = `PERTANYAAN ${current + 1} / ${questions.length}`;
  $("progressFill").style.width = `${((current + 1) / questions.length) * 100}%`;
  $("scoreLabel").textContent = `SKOR: ${score}`;
  $("feedback").hidden = true;
  $("feedback").className = "feedback";
  $("nextBtn").disabled = true;
  $("nextBtn").innerHTML = current === questions.length - 1 ? 'LIHAT HASIL <span>→</span>' : 'LANJUT <span>→</span>';
  document.querySelectorAll(".choice-btn").forEach((button) => {
    button.disabled = false;
    button.classList.remove("correct", "wrong");
  });
}

function chooseAnswer(choice) {
  if (answered) return;
  answered = true;
  const q = questions[current];
  const isCorrect = choice === q.answer;
  if (isCorrect) score += 1;

  document.querySelectorAll(".choice-btn").forEach((button, index) => {
    button.disabled = true;
    if (index === q.answer) button.classList.add("correct");
    if (index === choice && !isCorrect) button.classList.add("wrong");
  });

  const feedback = $("feedback");
  feedback.hidden = false;
  feedback.className = `feedback ${isCorrect ? "good" : "bad"}`;
  feedback.innerHTML = `<strong>${isCorrect ? "✓ GOOD CHOICE!" : "⚑ RED FLAG!"}</strong>${isCorrect ? q.good : q.bad}`;
  $("scoreLabel").textContent = `SKOR: ${score}`;
  $("nextBtn").disabled = false;
}

function showResult() {
  $("gameContent").hidden = true;
  $("gameResult").hidden = false;
  $("finalScore").textContent = `${score}/${questions.length}`;
  let title, message, icon;
  if (score === questions.length) {
    title = "Perfect choices!"; icon = "🏆";
    message = "Kamu berhasil memilih semua kebiasaan yang lebih baik. Pertahankan penggunaan handphone yang bijak!";
  } else if (score >= 3) {
    title = "Good progress!"; icon = "🌟";
    message = "Pilihanmu sudah cukup baik. Pelajari kembali situasi yang terlewat dan terus latih kebiasaan digital yang sehat.";
  } else {
    title = "It's a learning moment!"; icon = "💡";
    message = "Tidak apa-apa, ini kesempatan untuk belajar. Mulai dari satu perubahan kecil dan coba lagi!";
  }
  $("resultTitle").textContent = title;
  $("resultText").textContent = message;
  $("resultIcon").textContent = icon;
}

document.querySelectorAll(".choice-btn").forEach((button) => {
  button.addEventListener("click", () => chooseAnswer(Number(button.dataset.choice)));
});

$("nextBtn").addEventListener("click", () => {
  if (!answered) return;
  if (current < questions.length - 1) {
    current += 1;
    renderQuestion();
  } else {
    showResult();
  }
});

$("restartBtn").addEventListener("click", () => {
  current = 0;
  score = 0;
  renderQuestion();
});

$("menuToggle").addEventListener("click", () => {
  const isOpen = $("nav").classList.toggle("open");
  $("menuToggle").setAttribute("aria-expanded", String(isOpen));
});
document.querySelectorAll(".nav a").forEach((link) => {
  link.addEventListener("click", () => {
    $("nav").classList.remove("open");
    $("menuToggle").setAttribute("aria-expanded", "false");
  });
});
$("year").textContent = new Date().getFullYear();
renderQuestion();
